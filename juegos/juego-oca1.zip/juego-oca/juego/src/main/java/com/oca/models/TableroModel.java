package com.oca.models;

import java.util.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TableroModel {
    private ArrayList<CasillaModel> tablero;
    private ArrayList<JugadorModel> jugadores;
    private int numeroDeJugadores;
    private String[] nombresJugadores;
    private int turnoActual;
    private DadoModel dado;
    private boolean turnoExtra;
    private JugadorModel jugadorEnPozo;

    private final List<Integer> CASILLAS_OCA = Arrays.asList(
            5, 9, 14, 18, 23, 27, 32, 36, 41, 45, 50, 54, 59);

    public TableroModel() {
        tablero = new ArrayList<>();
        jugadores = new ArrayList<>();
        turnoActual = 1;
        turnoExtra = false;
        jugadorEnPozo = null;
    }

    public TableroModel(int numeroDeJugadores, DadoModel dado, String[] nombresJugadores) {
        this();
        this.numeroDeJugadores = numeroDeJugadores;
        this.nombresJugadores = nombresJugadores;
        this.dado = dado;
    }

    public void generarTablero() {
        tablero.clear();
        for (int numeroCasilla = 1; numeroCasilla <= 63; numeroCasilla++) {
            TipoCasilla tipo;
            if (CASILLAS_OCA.contains(numeroCasilla)) {
                tipo = TipoCasilla.OCA;
            } else {
                switch (numeroCasilla) {
                    case 6, 12 -> tipo = TipoCasilla.PUENTE;
                    case 19 -> tipo = TipoCasilla.POSADA;
                    case 31 -> tipo = TipoCasilla.POZO;
                    case 42 -> tipo = TipoCasilla.LABERINTO;
                    case 52 -> tipo = TipoCasilla.CARCEL;
                    case 58 -> tipo = TipoCasilla.CALAVERA;
                    case 63 -> tipo = TipoCasilla.META;
                    default -> tipo = TipoCasilla.NORMAL;
                }
            }
            tablero.add(new CasillaModel(numeroCasilla, tipo));
        }
    }

    public CasillaModel getCasilla(int numero) {
        return tablero.get(numero - 1);
    }

    public void inicializarJugadores() {
        jugadores.clear();
        for (String nombre : nombresJugadores) {
            JugadorModel j = new JugadorModel(nombre, 1, 0, false);
            getCasilla(1).getJugadoresEnCasilla().add(j);
            jugadores.add(j);
        }
    }

    public void avanzarTurno() {
        if (turnoExtra) {
            turnoExtra = false;
            return;
        }
        turnoActual = (turnoActual % numeroDeJugadores) + 1;
    }

    public JugadorModel getJugadorActual() {
        return jugadores.get(turnoActual - 1);
    }

    public String desplazarJugador(JugadorModel jugador, int cantidadDeCasillas) {
        if (jugador.getTurnosPerdidos() > 0) {
            jugador.setTurnosPerdidos(jugador.getTurnosPerdidos() - 1);
            return jugador.getJugadorNombre() + " pierde este turno.";
        }

        if (jugador.isEnPozo()) {
            return jugador.getJugadorNombre() + " está en el pozo y no puede moverse.";
        }

        int posActual = jugador.getUbicacionCasilla();
        int nuevaPos = Math.min(posActual + cantidadDeCasillas, 63);

        getCasilla(posActual).getJugadoresEnCasilla().remove(jugador);
        getCasilla(nuevaPos).getJugadoresEnCasilla().add(jugador);
        jugador.setUbicacionCasilla(nuevaPos);

        if (nuevaPos == 63) {// la meta
            return jugador.getJugadorNombre() + " llegó a la META y ganó la partida.";
        }

        return aplicarEfectoCasilla(jugador);
    }

    public String aplicarEfectoCasilla(JugadorModel jugador) {
        int pos = jugador.getUbicacionCasilla();
        String mensaje = "";

        switch (pos) {
            case 6 -> { // PUENTE
                moverJugador(jugador, 12);
                jugador.setTurnosPerdidos(1);
                mensaje = "Puente: avanzas a la casilla 12 y tienes turno extra.";
            }
            case 12 -> { // PUENTE inverso
                moverJugador(jugador, 6);
                jugador.setTurnosPerdidos(1);
                mensaje = "Puente: retrocedes a la casilla 6 y pierdes un turno.";
            }
            case 19 -> { // POSADA
                jugador.setTurnosPerdidos(1);
                mensaje = "Posada: pierdes un turno.";
            }
            case 31 -> { // POZO
                manejarPozo(jugador);
                mensaje = "Pozo: quedas atrapado hasta que otro jugador caiga aquí.";
            }
            case 42 -> { // LABERINTO
                moverJugador(jugador, 30);
                mensaje = "Laberinto: retrocedes a la casilla 30.";
            }
            case 52 -> { // CÁRCEL
                jugador.setTurnosPerdidos(3);
                mensaje = "Cárcel: pierdes tres turnos.";
            }
            case 58 -> { // CALAVERA
                moverJugador(jugador, 1);
                mensaje = "Calavera: vuelves a la casilla 1.";
            }
            default -> {
                if (CASILLAS_OCA.contains(pos)) {
                    moverASiguienteOca(jugador);
                    mensaje = "Oca:avanzas hasta la siguiente oca y vuelves a tirar.";
                    turnoExtra = true;
                } else {
                    mensaje = "Normal:avanzas normalmente";
                    moverJugador(jugador, pos);
                }
            }
        }
        return mensaje;
    }

    private void moverJugador(JugadorModel jugador, int nuevaPos) {
        getCasilla(jugador.getUbicacionCasilla()).getJugadoresEnCasilla().remove(jugador);
        getCasilla(nuevaPos).getJugadoresEnCasilla().add(jugador);
        jugador.setUbicacionCasilla(nuevaPos);
    }

    private void manejarPozo(JugadorModel jugador) {
        if (jugadorEnPozo == null) {
            jugadorEnPozo = jugador;
            jugador.setEnPozo(true);
        } else {
            jugadorEnPozo.setEnPozo(false);
            jugadorEnPozo = jugador;
            jugador.setEnPozo(true);
        }
    }

    private void moverASiguienteOca(JugadorModel jugador) {
        int posActual = jugador.getUbicacionCasilla();
        for (int oca : CASILLAS_OCA) {
            if (oca > posActual) {
                moverJugador(jugador, oca);
                return;
            }
        }
    }
}
