package com.oca.models;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class CasillaModel {
    private ArrayList<JugadorModel> jugadoresEnCasilla;
    private int numero;
    private TipoCasilla tipoCasilla;

    public CasillaModel(int numero, TipoCasilla tipoCasilla) {
        this.numero = numero;
        this.tipoCasilla = tipoCasilla;
        this.jugadoresEnCasilla = new ArrayList<>();
    }

    public void agregarJugadorACasilla(JugadorModel jugador) {
        jugadoresEnCasilla.add(jugador);
    }

    public void eliminarJugadorCasilla(JugadorModel jugador) {
        jugadoresEnCasilla.remove(jugador);
    }

}
