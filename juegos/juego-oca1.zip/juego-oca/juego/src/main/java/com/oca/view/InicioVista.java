package com.oca.view;

import javax.swing.*;
import lombok.Data;
import lombok.Getter;
import java.awt.*;

@Data
@Getter
public class InicioVista {
    private JFrame window;
    private JTextArea titleText;
    private JButton okButton;
    private JComboBox<Integer> playersNumberComboBox;
    private JPanel playersPanel;

    public InicioVista() {
        this.window = new JFrame("Seleccionar Jugadores");
        this.titleText = new JTextArea("Selecciona la cantidad de jugadores y escribe sus nombres:");
        this.okButton = new JButton("OK");
        Integer[] playersNumber = { 1, 2, 3, 4 };
        this.playersNumberComboBox = new JComboBox<>(playersNumber);
        this.playersPanel = new JPanel();
    }

    public void iniciarCargaJugadores() {
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setSize(500, 400);
        window.setLocationRelativeTo(null);
        window.setLayout(new BorderLayout(10, 10));

        // Título
        titleText.setEditable(false);
        titleText.setFont(new Font("SansSerif", Font.BOLD, 14));
        titleText.setBackground(window.getBackground());
        titleText.setFocusable(false);
        titleText.setMargin(new Insets(10, 10, 10, 10));
        window.add(titleText, BorderLayout.NORTH);

        // Panel central con combo y campos de jugadores
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        // Panel del combo alineado a la izquierda
        JPanel comboPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        comboPanel.add(new JLabel("Número de jugadores:"));
        comboPanel.add(playersNumberComboBox);
        centerPanel.add(comboPanel, BorderLayout.NORTH);

        // Campos para nombres de jugadores
        playersPanel.setLayout(new GridLayout(4, 1, 5, 5));
        playersPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        centerPanel.add(playersPanel, BorderLayout.CENTER);

        window.add(centerPanel, BorderLayout.CENTER);

        // Botón inferior
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(okButton);
        window.add(bottomPanel, BorderLayout.SOUTH);

        // Eventos
        playersNumberComboBox.addActionListener(e -> updatePlayers());
        okButton.addActionListener(e -> mostrarJugadores());

        // Inicializar campos
        updatePlayers();

        window.setVisible(true);
    }

    public int getNumeroJugadores() {
        return (int) playersNumberComboBox.getSelectedItem();
    }

    private void updatePlayers() {
        playersPanel.removeAll();
        int cantidad = (int) playersNumberComboBox.getSelectedItem();

        for (int i = 1; i <= cantidad; i++) {
            JPanel jugadorPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            jugadorPanel.add(new JLabel("Jugador " + i + ":"));
            JTextField nombreField = new JTextField(15);
            nombreField.setName("textField" + i);
            jugadorPanel.add(nombreField);
            playersPanel.add(jugadorPanel);
        }

        playersPanel.revalidate();
        playersPanel.repaint();
    }

    public boolean validateNames() {
        Component[] components = getPlayersPanel().getComponents();
        JTextField textField;
        int flag = 0;

        for (Component comp : components) {
            if (comp instanceof JPanel panel) {
                for (Component c : panel.getComponents()) {
                    if (c instanceof JTextField) {
                        textField = ((JTextField) c);
                        //System.out.println("JTextField");
                        //System.out.println(textField.getText());

                        if (!(textField.getText().isBlank())) {
                            flag++;
                        }

                    }
                }
            }
        }

        System.out.println(flag);

        return flag == (int) playersNumberComboBox.getSelectedItem();
    }

    private void mostrarJugadores() {
        Component[] componentes = playersPanel.getComponents();
        StringBuilder nombres = new StringBuilder("Jugadores:\n");

        for (Component comp : componentes) {
            if (comp instanceof JPanel panel) {
                for (Component c : panel.getComponents()) {
                    if (c instanceof JTextField field) {
                        nombres.append("- ").append(field.getText().isEmpty() ? "Sin nombre" : field.getText())
                                .append("\n");
                    }
                }
            }
        }

        System.out.println(validateNames());
        if (validateNames()) {
            JOptionPane.showMessageDialog(window, nombres.toString());
        } else {
            JOptionPane.showMessageDialog(window, "Nombres invalidos");

        }
    }

    public String[] getNombresJugadores() {
        String[] jugadores = new String[(int) playersNumberComboBox.getSelectedItem()];
        Component[] components = getPlayersPanel().getComponents();
        JTextField textField;
        int index = 0;
        String nombreJugador;

        for (Component comp : components) {
            if (comp instanceof JPanel panel) {
                for (Component c : panel.getComponents()) {
                    if (c instanceof JTextField) {
                        textField = ((JTextField) c);
                        System.out.println(textField.getText());
                        if (!(textField.getText().isBlank())) {
                            nombreJugador = textField.getText();
                            System.out.println("NOMBRE JUGADOR:" + nombreJugador);
                            jugadores[index] = nombreJugador;
                            index++;
                        }

                    }
                }

            }
        }

        return jugadores;
    }

}
