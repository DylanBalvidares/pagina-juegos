package com.oca.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DadoModel {
    private int numero;

    public int tirarDado() {
        this.numero = (int) (Math.random() * 6) + 1;
        return numero;
    }
}
