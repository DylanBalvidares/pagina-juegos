package com.oca.models;

import java.awt.Color;

public enum TipoCasilla {
    NORMAL("No pasa nada, sigue jugando.", Color.LIGHT_GRAY),
    OCA("¡De oca a oca y tiro porque me toca!", new Color(230, 230, 250)),
    PUENTE("¡Has cruzado un puente!", new Color(180, 238, 180)),
    POSADA("Descansas, pierdes un turno.", new Color(255, 220, 170)),
    POZO("Caíste en el pozo, pierdes turnos.", new Color(170, 210, 255)),
    LABERINTO("Retrocedes al 30.", new Color(210, 200, 230)),
    CARCEL("Estás preso,pierdes tres turnos.", new Color(255, 160, 160)),
    CALAVERA("Vuelves al inicio.", new Color(200, 120, 120)),
    META("¡Llegaste al final, ganaste!", new Color(255, 215, 0));

    private final String mensaje;
    private final Color color;

    TipoCasilla(String mensaje, Color color) {
        this.mensaje = mensaje;
        this.color = color;
    }

    public String getMensaje() {
        return mensaje;
    }

    public Color getColor() {
        return color;
    }
}
