package com.oca.view;

import javax.swing.*;
import com.oca.models.JugadorModel;
import com.oca.models.TipoCasilla;

import lombok.Getter;
import java.awt.*;
import java.util.ArrayList;

@Getter
public class TableroVista extends JFrame {
    private JPanel tableroPanel;
    private JLabel turnoLabel;
    private JButton tirarDadoButton;
    private JLabel dadoLabel;
    private JLabel mensajeLabel;
    private ArrayList<JugadorModel> posicionesJugadores;

    private JPanel[][] casillas;
    private JLabel[][] jugadorLabels;

    public TableroVista() {
        this.posicionesJugadores = new ArrayList<>();
        setTitle("Juego de la Oca");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        iniciarComponentes();
    }

    public void iniciarTablero() {
        setVisible(true);
    }

    private void iniciarComponentes() {
        setLayout(new BorderLayout());

        turnoLabel = new JLabel("Turno del jugador 1");
        turnoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        turnoLabel.setFont(new Font("Arial", Font.BOLD, 18));
        JPanel turnoPanel = new JPanel(new BorderLayout());
        turnoPanel.add(turnoLabel, BorderLayout.CENTER);
        add(turnoPanel, BorderLayout.NORTH);

        tableroPanel = new JPanel();
        tableroPanel.setLayout(new GridLayout(8, 8));
        tableroPanel.setPreferredSize(new Dimension(400, 400));
        tableroPanel.setBackground(new Color(240, 240, 240));

        generarCasillas();

        JPanel centroPanel = new JPanel(new GridBagLayout());
        centroPanel.add(tableroPanel);
        add(centroPanel, BorderLayout.CENTER);

        tirarDadoButton = new JButton("🎲 Tirar dado");
        dadoLabel = new JLabel("🎲 ?");
        dadoLabel.setFont(new Font("Arial", Font.BOLD, 20));
        dadoLabel.setHorizontalAlignment(SwingConstants.CENTER);

        mensajeLabel = new JLabel(" ");
        mensajeLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        mensajeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mensajeLabel.setForeground(Color.DARK_GRAY);

        JPanel dadoPanel = new JPanel(new BorderLayout());

        // Panel superior para el mensaje centrado
        JPanel mensajePanel = new JPanel(new GridBagLayout());
        mensajePanel.add(mensajeLabel);
        mensajePanel.setPreferredSize(new Dimension(0, 50)); // le da más altura
        dadoPanel.add(mensajePanel, BorderLayout.NORTH);

        // Panel inferior para dado y botón
        JPanel lineaDado = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        lineaDado.add(dadoLabel);
        lineaDado.add(tirarDadoButton);
        dadoPanel.add(lineaDado, BorderLayout.CENTER);

        add(dadoPanel, BorderLayout.SOUTH);

        PanelGlosario glosario = new PanelGlosario();
        glosario.setPreferredSize(new Dimension(300, 300)); // Ajusta el tamaño
        add(glosario, BorderLayout.EAST); // Lo pone al costado derecho
    }

    private void generarCasillas() {
        int filas = 8, columnas = 8;
        int[][] tablero = generarEspiral(filas, columnas);

        casillas = new JPanel[filas][columnas];
        jugadorLabels = new JLabel[filas][columnas];

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                int numero = tablero[i][j];
                Color color = obtenerColorCasilla(numero);

                JPanel casilla = new JPanel(new BorderLayout());
                casilla.setBackground(color);
                casilla.setBorder(BorderFactory.createLineBorder(Color.BLACK));

                JLabel numeroLabel = new JLabel(String.valueOf(numero), SwingConstants.CENTER);
                numeroLabel.setFont(new Font("Arial", Font.BOLD, 12));

                JLabel jugadorLabel = new JLabel("", SwingConstants.CENTER);
                jugadorLabel.setFont(new Font("Arial", Font.BOLD, 14));

                casilla.add(numeroLabel, BorderLayout.NORTH);
                casilla.add(jugadorLabel, BorderLayout.SOUTH);

                casillas[i][j] = casilla;
                jugadorLabels[i][j] = jugadorLabel;

                tableroPanel.add(casilla);
            }
        }
    }

    public void actualizarTurnoLabel(int turno, String nombre) {
        this.turnoLabel.setText("Turno del jugador " + turno + ", " + nombre);
    }

    public void mostrarNumeroDado(int numero, String nombreJugador) {
        this.dadoLabel
                .setText(nombreJugador.toUpperCase() + ":🎲 Dado que salió:" + numero);

        Timer temp = new Timer(2000, e -> this.dadoLabel.setText(""));
        temp.setRepeats(false);
        temp.start();
    }

    public void mostrarMensaje(String mensaje) {
        this.mensajeLabel.setText(mensaje);
        this.mensajeLabel.setHorizontalAlignment(SwingConstants.CENTER);

    }

    private int[][] generarEspiral(int filas, int columnas) {
        int[][] matriz = new int[filas][columnas];
        boolean[][] visitado = new boolean[filas][columnas];
        int[] dx = { 0, 1, 0, -1 };
        int[] dy = { 1, 0, -1, 0 };
        int x = 0, y = 0, dir = 0;

        for (int num = 1; num <= filas * columnas; num++) {
            matriz[x][y] = num;
            visitado[x][y] = true;

            int nx = x + dx[dir];
            int ny = y + dy[dir];

            if (nx >= 0 && nx < filas && ny >= 0 && ny < columnas && !visitado[nx][ny]) {
                x = nx;
                y = ny;
            } else {
                dir = (dir + 1) % 4;
                x += dx[dir];
                y += dy[dir];
            }
        }
        return matriz;
    }

    private Color obtenerColorCasilla(int numero) {
        // Colores por tipo de casilla
        switch (numero) {
            // --- OCA ---
            case 5:
            case 9:
            case 14:
            case 18:
            case 23:
            case 27:
            case 32:
            case 36:
            case 41:
            case 45:
            case 50:
            case 54:
            case 59:
                return new Color(230, 230, 250); // lavanda suave

            // --- PUENTE, POSADA, POZO, LABERINTO, CÁRCEL, CALAVERA, META ---
            case 6:
            case 12:
            case 19:
            case 31:
            case 42:
            case 52:
            case 58:
            case 63:
                return colorEspecial(numero);

            // --- Casillas normales ---
            default:
                return Color.LIGHT_GRAY;
        }
    }

    private Color colorEspecial(int numero) {
        switch (numero) {
            case 6: // PUENTE
            case 12:
                return new Color(180, 238, 180); // verde suave

            case 19: // POSADA
                return new Color(255, 220, 170); // naranja pastel

            case 31: // POZO
                return new Color(170, 210, 255); // azul suave

            case 42: // LABERINTO
                return new Color(210, 200, 230); // violeta pálido

            case 52: // CÁRCEL
                return new Color(255, 160, 160); // rojo pálido

            case 58: // CALAVERA
                return new Color(200, 120, 120); // rojo oscuro suave

            case 63: // META
                return Color.RED; // azul claro elegante

            default:// NORMAL
                return Color.LIGHT_GRAY;
        }
    }

    public void actualizarJugadores(ArrayList<JugadorModel> jugadores) {
        this.posicionesJugadores = jugadores;

        // Limpiar los textos anteriores
        for (int i = 0; i < jugadorLabels.length; i++) {
            for (int j = 0; j < jugadorLabels[i].length; j++) {
                jugadorLabels[i][j].setText("");
                jugadorLabels[i][j].setForeground(Color.BLACK);
            }
        }

        int filas = 8, columnas = 8;
        int[][] tablero = generarEspiral(filas, columnas);

        // Colores llamativos para los jugadores
        Color[] colores = {
                Color.RED,
                new Color(0, 180, 0), // verde fuerte
                new Color(0, 120, 255), // azul
                Color.MAGENTA,
                Color.ORANGE,
                Color.YELLOW
        };

        java.util.Map<Integer, StringBuilder> casillaIniciales = new java.util.HashMap<>();
        java.util.Map<Integer, Color> colorPorCasilla = new java.util.HashMap<>();

        for (int i = 0; i < jugadores.size(); i++) {
            JugadorModel jugador = jugadores.get(i);
            int casilla = jugador.getUbicacionCasilla();
            String inicial = jugador.getJugadorNombre().substring(0, 1).toUpperCase();

            casillaIniciales.computeIfAbsent(casilla, k -> new StringBuilder()).append(inicial);
            colorPorCasilla.put(casilla, colores[i % colores.length]);
        }

        // Dibujar las iniciales en el tablero
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                int numeroCasilla = tablero[fila][col];
                if (casillaIniciales.containsKey(numeroCasilla)) {
                    JLabel label = jugadorLabels[fila][col];
                    label.setText(casillaIniciales.get(numeroCasilla).toString());
                    label.setForeground(colorPorCasilla.get(numeroCasilla));
                    label.setFont(label.getFont().deriveFont(Font.BOLD, 16f)); // más grande y en negrita
                }
            }
        }

        tableroPanel.revalidate();
        tableroPanel.repaint();
    }

    public void deshabilitarBotonTirar() {
        tirarDadoButton.setEnabled(false);
    }
}

class PanelGlosario extends JPanel {
    public PanelGlosario() {
        setLayout(new GridLayout(0, 1));
        setBorder(BorderFactory.createTitledBorder("Glosario de Casillas"));
        setBackground(Color.WHITE);

        for (TipoCasilla tipo : TipoCasilla.values()) {
            JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT));
            fila.setBackground(Color.WHITE);

            JLabel colorLabel = new JLabel("   ");
            colorLabel.setOpaque(true);
            colorLabel.setBackground(tipo.getColor());
            colorLabel.setPreferredSize(new Dimension(25, 25));
            colorLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel textoLabel = new JLabel(tipo.name() + "—" + tipo.getMensaje());

            fila.add(colorLabel);
            fila.add(textoLabel);
            add(fila);
        }
    }
}
