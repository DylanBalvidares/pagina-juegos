package com.oca;

import javax.swing.SwingUtilities;
import com.oca.controller.JuegoController;
import com.oca.models.DadoModel;
import com.oca.models.TableroModel;
import com.oca.view.InicioVista;
import com.oca.view.TableroVista;

public class Juego {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(
                () -> new JuegoController(new InicioVista(), new TableroVista(), new TableroModel(), new DadoModel())
                        .iniciarJuego());
    }
}
