package com.oca.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import com.oca.view.*;
import com.oca.models.DadoModel;
import com.oca.models.TableroModel;
import com.oca.models.JugadorModel;

import lombok.Getter;

@Getter
public class JuegoController {
    private InicioVista inicioVista;
    private TableroVista tableroVista;
    private TableroModel tablero;
    private boolean flagJugadoresValidos;
    private DadoModel dado;

    public JuegoController(InicioVista inicioVista, TableroVista tableroVista, TableroModel tablero,
            DadoModel dadoModel) {
        this.inicioVista = inicioVista;
        this.tableroVista = tableroVista;
        this.tablero = tablero;
        this.dado = dadoModel;
        this.flagJugadoresValidos = false;
    }

    public void iniciarJuego() {
        inicioVista.iniciarCargaJugadores();
        inicioVista.getOkButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (inicioVista.validateNames()) {

                    tablero.setNumeroDeJugadores(inicioVista.getNumeroJugadores());
                    tablero.setNombresJugadores(inicioVista.getNombresJugadores());
                    tablero.generarTablero();
                    tablero.inicializarJugadores();

                    System.out.println("TABLERO:" + tablero.getTablero().toString());
                    System.out.println("JUGADORES->{" + Arrays.toString(tablero.getNombresJugadores()) + "}");
                    System.out.println("NUMERO DE JUGADORES:" + tablero.getNumeroDeJugadores());

                    inicioVista.getWindow().dispose();
                    tableroVista.iniciarTablero();

                    tableroVista.actualizarJugadores(tablero.getJugadores());

                    accionDadoBoton();
                } else {
                    System.out.println("validate names:false");// debug
                }
            }
        });
    }

    public void accionDadoBoton() {
        tableroVista.getTirarDadoButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (tablero.getJugadorActual().getUbicacionCasilla() != 63) {
                    JugadorModel jugadorActual = tablero.getJugadorActual();

                    if (jugadorActual.getTurnosPerdidos() > 0) {
                        jugadorActual.setTurnosPerdidos(jugadorActual.getTurnosPerdidos() - 1);
                        System.out.println(jugadorActual.getJugadorNombre() + " pierde su turno. Le quedan " +
                                jugadorActual.getTurnosPerdidos() + " turnos sin jugar.");
                        tablero.avanzarTurno();
                        tableroVista.actualizarTurnoLabel(tablero.getTurnoActual(),
                                tablero.getJugadorActual().getJugadorNombre());
                        return;
                    }

                    if (jugadorActual.isEnPozo()) {
                        System.out.println(
                                jugadorActual.getJugadorNombre() + " está atrapado en el pozo. No puede jugar.");
                        tablero.avanzarTurno();
                        tableroVista.actualizarTurnoLabel(tablero.getTurnoActual(),
                                tablero.getJugadorActual().getJugadorNombre());
                        return;
                    }

                    int numero = dado.tirarDado();
                    tableroVista.mostrarNumeroDado(numero, jugadorActual.getJugadorNombre());

                    String resultado = tablero.desplazarJugador(jugadorActual, numero);
                    tableroVista.mostrarMensaje(
                            "<html><b>JUGADOR " + jugadorActual.getJugadorNombre() + ":</b><html>" + resultado);

                    tableroVista.actualizarJugadores(tablero.getJugadores());

                    tablero.avanzarTurno();
                    tableroVista.actualizarTurnoLabel(tablero.getTurnoActual(),
                            tablero.getJugadorActual().getJugadorNombre());

                } else {
                    tableroVista.deshabilitarBotonTirar();
                    tableroVista.mostrarMensaje(tablero.getJugadorActual().getJugadorNombre() + " GANO EL JUEGO!");
                }
            }
        });
    }
}
