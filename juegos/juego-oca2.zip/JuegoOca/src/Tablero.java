import java.util.Scanner;
import java.util.List;
public class Tablero{;
    private Jugador jugador;
    public Tablero(){

    }
    public void limpiarPantalla() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            System.err.println("CLEAN->" + e);
        }
    }
    public void esperar(int tiempo) {
        try {
            Thread.sleep(tiempo);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
