import java.util.Scanner;
public class Casillas {
    private Jugador jugador;
    private int casilla;
    private Dado dado;

    public Casillas(){
        casilla=0;
    }

    public void Posada(){
        jugador.Pierdeturno();
    }

    public void Pozo(){
        if (jugador.getPosicion() == 31){
        
            jugador.Pierdeturno();
        }
    }
    public void Mover(Dado dado){
        jugador.iniciarScanner();
        dado.Dadotirar();
        dado.getDado();
        jugador.setPosicion(dado.getDado());
        switch(casilla){
            case 6,12:
                Posada();
            case 19:
                Posada();
            case 42:
                jugador.setPosicion(19);
            case 52:
                
        }
    }
}
