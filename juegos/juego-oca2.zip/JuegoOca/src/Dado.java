public class Dado {
    private int dado;
    private Tablero tablero;

    public Dado(Tablero tablero) {
        this.tablero = tablero;
    }

    public void Dadotirar(){
        System.out.println("tirando dado");
        for (int i=0;i<2;i++){
            tablero.limpiarPantalla();
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("tirando dado.");
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("tirando dado..");
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("tirando dado...");
            tablero.esperar(300);
            tablero.limpiarPantalla();
        }
        dado = (int) (Math.random() * 6) + 1;
        System.out.println("Te toco el "+getDado());
    }
    public int getDado() {
        return dado;
    }
    public void setDado(int dado) {
        this.dado = dado;
    }
}
