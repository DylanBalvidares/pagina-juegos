import java.util.Scanner;
public class Jugador {
    private String nombre;
    private int posicion;
    private String estado;
    private int turno;
    private Tablero tablero;
    private Dado dado;
    public void Pierdeturno(){
        if (estado.equals("Jugando")){
            System.out.println("Pierdes el turno!");
            estado = "Pierdeturno";
        }else{
            System.out.println("Error en los turnos");
        }
    }
    public void avanzarCasilla(){
        setPosicion(dado.getDado() + posicion);
        for (int i=0;i<2;i++){
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("Moviendose.");
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("Moviendose..");
            tablero.esperar(300);
            tablero.limpiarPantalla();
            System.out.println("Moviendose...");
            tablero.esperar(300);
            tablero.limpiarPantalla();
        }
        System.out.println("Avanzaste a la casilla "+getPosicion());
    }

    public void iniciarJugadores(int cantidad){
        iniciarScanner();
        System.out.println("Cuantos jugadores juegan?");
        try{
            int cantidad = sc.nextInt();
        }catch(Exception exception){
            System.out.println("Error al poner la cantidad de jugadores!");
        }
    }

    public void iniciarScanner(){
        Scanner sc = new Scanner(System.in);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
}
