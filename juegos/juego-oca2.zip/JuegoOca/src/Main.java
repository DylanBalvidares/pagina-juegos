public class Main {
    private Dado dado = new Dado();

    public static void main(String[] args) {

        Main main = new Main();
        main.dado.Dadotirar();
    }
}
