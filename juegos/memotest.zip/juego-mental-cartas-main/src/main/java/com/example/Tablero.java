package com.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Tablero {
    private ArrayList<Carta> cartas;

    public Tablero() {
        this.cartas = new ArrayList<>();
    }

    public void generarTablero() {
        cartas.clear();
        final int TOTAL_PARES = 4; 
        int id = 1;

        for (int i = 0; i < TOTAL_PARES; i++) {
            Carta carta1 = new Carta();
            Carta carta2 = new Carta();

            carta1.setId(id);
            carta2.setId(id);

            cartas.add(carta1);
            cartas.add(carta2);
            id++;
        }

        Collections.shuffle(cartas);

        for (int i = 0; i < cartas.size(); i++) {
            cartas.get(i).setValorQueSeMuestraAlEstarDadaVuelta(i);
        }
    }

    public void ocultarCartas() {
        System.out.println("========== ¡LAS CARTAS SE HAN OCULTADO! ==========");
        imprimirCartas(false);
    }

    public void revelarCartas() {
        System.out.println("========== ¡LAS CARTAS SE HAN REVELADO! ==========");
        imprimirCartas(true);
    }

    private void imprimirCartas(boolean mostrarId) {
        String[] plantilla = {
                "┌─────────┐",
                "│         │",
                "│         │",
                "│   %s   │",
                "│         │",
                "│         │",
                "└─────────┘"
        };

        int cartasPorFila = 4;
        int total = cartas.size();

        for (int inicio = 0; inicio < total; inicio += cartasPorFila) {
            int fin = Math.min(inicio + cartasPorFila, total);
            List<Carta> sublista = cartas.subList(inicio, fin);

            for (int i = 0; i < plantilla.length; i++) {
                for (int j = 0; j < sublista.size(); j++) {
                    Carta carta = sublista.get(j);
                    String valor = mostrarId
                            ? String.format("%-3s", carta.getId())
                            : String.format("%-3s", inicio + j); 
                    if (i == 3)
                        System.out.print(String.format(plantilla[i], valor) + " ");
                    else
                        System.out.print(plantilla[i] + " ");
                }
                System.out.println();
            }
            System.out.println();
        }
    }

    public boolean eliminarParDeCartas(int pos1, int pos2) {
        if (pos1 < 0 || pos2 < 0 || pos1 >= cartas.size() || pos2 >= cartas.size()) {
            System.out.println("Posiciones inválidas.");
            return false;
        }

        Carta c1 = cartas.get(pos1);
        Carta c2 = cartas.get(pos2);

        if (c1.getId() == c2.getId()) {
            if (pos1 > pos2) {
                cartas.remove(pos1);
                cartas.remove(pos2);
            } else {
                cartas.remove(pos2);
                cartas.remove(pos1);
            }
            System.out.println("¡Par correcto! Cartas eliminadas");
            return true;
        } else {
            System.out.println("Las cartas no coinciden.");
            return false;
        }
    }

    public Carta obtenerCarta(int pos) {
        if (pos < 0 || pos >= cartas.size()) {
            System.out.println("Índice fuera de rango: " + pos);
            return null;
        }
        return cartas.get(pos);
    }
}