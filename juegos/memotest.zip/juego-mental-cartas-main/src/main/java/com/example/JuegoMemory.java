package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class JuegoMemory {
    private List<Jugador> jugadores;
    private Tablero tablero;
    private int turnoActual;
    private Scanner sc;
    private int elegirPrimero;
    private int elegirSegundo;

    public JuegoMemory() {
        this.jugadores = new ArrayList<>();
        this.tablero = new Tablero();
        this.turnoActual = 0;
        this.sc = new Scanner(System.in);
    }

    public void iniciarJuego() {
        iniciarJugadores();
        iniciarTablero();
        System.out.println("Cargando tablero...");

        boolean juegoActivo = true;

        while (juegoActivo) {
            esperar(1000);
            limpiarPantalla();
            tablero.revelarCartas();
            System.out.println("*Las cartas se ocultarán en 4 segundos...");
            esperar(4000);
            limpiarPantalla();
            tablero.ocultarCartas();
            esperar(500);

            Jugador jugadorActual = jugadores.get(turnoActual);
            System.out.println("\n=== TURNO DE: " + jugadorActual.getNombreJugador() + " ===");

            elegirPar();

            if (comprobarParDeCartas()) {
                System.out.println("¡Acertaste un par!");
                tablero.eliminarParDeCartas(elegirPrimero, elegirSegundo);
                jugadorActual.setPuntosJugador(jugadorActual.getPuntosJugador() + 1);

                if (tablero.getCartas().isEmpty()) {
                    System.out.println("\n¡" + jugadorActual.getNombreJugador() + " ha ganado el juego!");
                    juegoActivo = false;
                    break;
                }

                if (jugadorActual.getCartaEspecial().turnoExtra()) {
                    System.out.println("¡Tenés un turno extra por la carta especial!");
                } else {
                    cambiarTurno();
                }

            } else {
                System.out.println("No es un par, turno siguiente.");
                cambiarTurno();
            }
        }

        System.out.println("\n=== PUNTAJES FINALES ===");
        for (Jugador jugador : jugadores) {
            System.out.println(jugador.getNombreJugador() + ": " + jugador.getPuntosJugador() + " puntos");
        }
    }

    private void iniciarJugadores() {
        System.out.print("Nombre del jugador 1: ");
        Jugador jugador1 = new Jugador();
        jugador1.setNombreJugador(sc.nextLine());
        jugador1.setCartaEspecial(new CartaEspecial());

        System.out.print("Nombre del jugador 2: ");
        Jugador jugador2 = new Jugador();
        jugador2.setNombreJugador(sc.nextLine());
        jugador2.setCartaEspecial(new CartaEspecial());

        jugadores.add(jugador1);
        jugadores.add(jugador2);
    }

    private void iniciarTablero() {
        tablero = new Tablero();
        tablero.generarTablero();
    }

    private void elegirPar() {
        int total = tablero.getCartas().size();

        // Primer carta
        while (true) {
            System.out.print("Primer carta (0-" + (total - 1) + "): ");
            if (sc.hasNextInt()) {
                elegirPrimero = sc.nextInt();
                if (elegirPrimero >= 0 && elegirPrimero < total)
                    break;
            } else {
                sc.next();
            }
            System.out.println("Entrada inválida, intente de nuevo.");
        }

        // Segunda carta
        while (true) {
            System.out.print("Segunda carta (0-" + (total - 1) + "): ");
            if (sc.hasNextInt()) {
                elegirSegundo = sc.nextInt();
                if (elegirSegundo >= 0 && elegirSegundo < total && elegirSegundo != elegirPrimero)
                    break;
            } else {
                sc.next(); 
            }
            System.out.println("Entrada inválida o igual a la primera carta, intente de nuevo.");
        }
    }

    private boolean comprobarParDeCartas() {
        Carta c1 = tablero.obtenerCarta(elegirPrimero);
        Carta c2 = tablero.obtenerCarta(elegirSegundo);
        return c1 != null && c2 != null && c1.getId() == c2.getId();
    }

    private void cambiarTurno() {
        turnoActual = (turnoActual + 1) % jugadores.size();
    }

    private void esperar(int tiempo) {
        try {
            Thread.sleep(tiempo);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void limpiarPantalla() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            System.err.println("CLEAN->" + e);
        }
    }
}
