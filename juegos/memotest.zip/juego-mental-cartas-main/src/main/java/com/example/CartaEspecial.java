package com.example;

public class CartaEspecial extends Carta {

    private boolean turnoExtraDisponible;

    public CartaEspecial() {
        super();
        this.turnoExtraDisponible = true;
    }

    public boolean turnoExtra() {
        if (!turnoExtraDisponible)
            return false;

        boolean resultado = Math.random() < 0.33;

        if (resultado) {
            turnoExtraDisponible = false;
        }

        return resultado;
    }

    public void reiniciarTurnoExtra() {
        turnoExtraDisponible = true;
    }
}
