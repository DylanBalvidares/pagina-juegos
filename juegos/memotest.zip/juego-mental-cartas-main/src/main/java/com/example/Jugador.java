package com.example;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Jugador {
    private String nombreJugador;
    private int puntosJugador;
    private Carta carta;
    private CartaEspecial cartaEspecial;

    public boolean sumarPunto(Carta carta) {
        if (carta.esPar(carta)) {
            System.out.println("Has sumado un punto :D");
            puntosJugador++;
            return true;
        } else {
            System.out.println("No has sumado un punto :C");
            return false;
        }
    }

    public void tieneTurnoExtra() {
        if (cartaEspecial.turnoExtra()) {
            System.out.println("¡Tenés 1 turno extra!");
        } else {
            System.out.println("No tenés turno extra.");
        }
    }
}
