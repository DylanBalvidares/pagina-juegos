package com.example;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class Carta {
    protected int id;
    protected int valorQueSeMuestraAlEstarDadaVuelta;

    protected Carta() {
        this.id = 0;
        this.valorQueSeMuestraAlEstarDadaVuelta = 0;
    }

    protected boolean esPar(Carta carta) {
        return this.id == carta.getId();
    }

    protected void generarNumero() {
        id = (int) (Math.random() * 10);
    }

    @Override
    public String toString() {
        return String.valueOf(getId());
    }
}