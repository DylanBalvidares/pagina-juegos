# juego-mental-cartas
# actualizar los indices visibles de las cartas,porque al borrar una carta,se desordenan los indices
