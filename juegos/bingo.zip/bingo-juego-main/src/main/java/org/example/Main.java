package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.InputMismatchException;

//dylan->1,7,12,13
//pepe ->17,18,10,13

public class Main {
    
    private static Scanner sc = new Scanner(System.in);// pertenece a la clase,no al objeto,porque JVM no crea un objeto
                                                       // Main.

    public static void main(String[] args) {
        Bingo bingo = new Bingo(crearJugadores(leerCantidadDeJugadores()));
        bingo.jugar();
    }

    public static List<Jugador> crearJugadores(int cantidadDeJugadores) {
        List<Jugador> jugadores = new ArrayList<>();

        for (int i = 0; i < cantidadDeJugadores; i++) {
            jugadores.add(new Jugador(leerNombre()));
        }

        return jugadores;
    }

    public static String leerNombre() {
        System.out.print("*NOMBRE DEL JUGADOR:");

        return sc.nextLine();
    }

    public static int leerCantidadDeJugadores() {
        int numero;

        while (true) {
            System.out.print("*NUMERO DE JUGADORES:");

            try {
                numero = sc.nextInt();
                sc.nextLine();

                if (numero < 5) {
                    return numero;
                } else {
                    System.out.println("*SON MUCHOS JUGADORES*");
                }

            } catch (InputMismatchException ex) {
                sc.nextLine();

            }
        }
    }
}
