package org.example;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Bolillero {
    private HashSet<Integer> bolillas;
    private int indiceActual;// sin usar

    public Bolillero() {
        this.bolillas = generarBolillasMezcladas();
    }

    public HashSet<Integer> generarBolillasMezcladas() {
        final int LENGTH = 20;
        int bolilla = 0;

        HashSet<Integer> bolillas = new HashSet<>();

        while (bolillas.size() + 1 < LENGTH) {
            bolilla = 1 + (int) (Math.random() * 20);// ===CAMBIAR HASTA * 99 ===
            bolillas.add(bolilla);
        }

        return bolillas;
    }

    public int sacarBolilla() {
        if (this.bolillas.isEmpty()) {
            return -1;
        }
        List<Integer> bolitasTemp = new ArrayList<>(bolillas);
        Collections.shuffle(bolitasTemp);
        int bolilla = bolitasTemp.get(0);
        this.bolillas.remove(bolilla);
        return bolilla;
    }

}
