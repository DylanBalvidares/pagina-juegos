package org.example;

import java.util.List;
import java.util.Scanner;

import lombok.Data;

@Data
public class Bingo {
    private List<Jugador> jugadores;
    private Bolillero bolillero;
    private Scanner sc = new Scanner(System.in);

    public Bingo(List<Jugador> jugadores) {
        this.jugadores = jugadores;
        this.bolillero = new Bolillero();
    }

    public void jugar() {
        boolean jugando = true;

        int bolilla;

        while (jugando) {
            limpiarPantalla();
            opcionesJugadores();
            esperar(450);
            bolilla = this.bolillero.sacarBolilla();

            if (bolilla == -1) {
                limpiarPantalla();
                bolilleroVacio();
                jugando = false;
                esperar(500);
                mostrarCartonesJugadores();
                break;
            }

            mensajeSacandoBolilla(bolilla);
            System.out.println("*BOLILLA QUE SALIO->" + bolilla);

            for (Jugador jugador : jugadores) {
                if (jugador.marcarNumero(bolilla)) {
                    System.out.println(
                            "\u001B[32m ==" + jugador.getNombre().toUpperCase() + ", ACERTASTE!, LA BOLILLA " + bolilla
                                    + " ESTA EN TU CARTON! ==" + "\u001B[0m");
                } else {
                    System.out.println(
                            " \u001B[31m ==" + jugador.getNombre().toUpperCase() + " ,LA BOLILLA " + bolilla
                                    + " NO ESTA EN TU CARTON! ==\u001B[0m\n");
                }

                if (jugador.gano()) {
                    jugando = false;
                    System.out.println("\u001B[32m === ¡" + jugador.getNombre().toUpperCase() + " GANO! ===\u001B[0m");
                    break;
                }

            }

            esperar(450);

            proximaTirada();
            esperar(550);

        }

    }

    public void proximaTirada() {
        while (true) {
            System.out.print("**PULSE enter PARA PROXIMA RONDA**");
            String seguir = sc.nextLine();

            if (seguir.isEmpty()) {
                break;
            }
        }
    }

    public void opcionesJugadores() {
        String opcion;
        boolean loop = true;
        while (loop) {
            System.out.println("============================================================");
            System.out.println("**PULSE o PARA VER SU LOS CARTONES DE LOS JUGADORES**");
            System.out.println("**PULSE i PARA TIRAR EL BOLILLERO**");
            System.out.println("============================================================");
            System.out.print("->");
            opcion = sc.nextLine();

            switch (opcion) {
                case "i":
                    loop = false;
                    break;
                case "o":
                    limpiarPantalla();
                    mostrarCartonesJugadores();
                    break;
                default:
                    System.out.println("**LETRA INVALIDA**");
                    esperar(550);
                    limpiarPantalla();
                    break;
            }

        }

    }

    public void mostrarPuntajeJugadores() {
        for (Jugador jugador : jugadores) {
            System.out.println("*PUNTAJE DE " + jugador.getNombre() + "->" + jugador.getCarton().getAciertos());
        }
    }

    public void mostrarCartonesJugadores() {
        for (Jugador jugador : jugadores) {
            System.out.println("=================================");
            System.out.println("*CARTON DE " + jugador.getNombre().toUpperCase() + " " +
                    jugador.getCarton().getNumeros());
            System.out.println("*MARCADOS DE " + jugador.getNombre() + " " +
                    jugador.getCarton().getMarcados());
            System.out.println("*CANTIDAD DE TIROS:" + jugador.getCarton().getTiros());
            System.out.println("*PUNTAJE:" + jugador.getCarton().getAciertos());
            System.out.println("=================================");
        }
    }

    public void mensajeSacandoBolilla(int bolilla) {
        System.out.print("SACANDO BOLILLA");

        for (int i = 0; i < 3; i++) {
            System.out.print(".");
            esperar(500);
        }
        System.out.println("");
    }

    public void bolilleroVacio() {
        System.out.println("========BOLILLERO VACIO========");
    }

    public void esperar(int tiempo) {
        try {
            Thread.sleep(tiempo);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void limpiarPantalla() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            System.err.println("CLEAN->" + e);
        }
    }

}
