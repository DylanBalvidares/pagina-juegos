package org.example;

import java.util.HashSet;

import lombok.Data;

@Data
public class Carton {
    private int aciertos;
    private int tiros;
    private HashSet<Integer> numeros;
    private HashSet<Integer> marcados;

    public Carton() {
        this.aciertos = 0;
        this.tiros = 0;
        this.numeros = generarCarton();
        this.marcados = new HashSet<>();
    }

    public void incrementarTiros() {
        this.tiros++;
    }

    public boolean marcarNumero(int numero) {
        if (numeros.contains(numero) && !marcados.contains(numero)) {
            marcados.add(numero);
            this.aciertos++;
            this.tiros++;
            return true;
        } else {
            this.tiros++;
            return false;
        }
    }

    public boolean estaCompleto() {
        return marcados.containsAll(numeros);
    }

    public HashSet<Integer> generarCarton() {
        final int LENGTH = 4;
        int numero = 0;// ESTO ES SOSPECHOSO

        HashSet<Integer> carton = new HashSet<>();

        while (carton.size() + 1 < LENGTH) {
            numero = 1 + (int) (Math.random() * 20); // ===CAMBIAR HASTA * 99===
            carton.add(numero);
        }

        return carton;
    }

}
