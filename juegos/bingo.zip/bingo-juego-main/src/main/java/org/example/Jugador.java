package org.example;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Jugador {
    private String nombre;
    private Carton carton;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.carton = new Carton();
    }

    public boolean marcarNumero(int numero) {
        return carton.marcarNumero(numero);
    }

    public boolean gano() {
        return carton.estaCompleto();
    }
}
