//CLASE CONTROLADOR,coordina vista con modelo

package com.juego;

public class Controller {
    private Game game;
    private GameView view;

    public Controller(Game game, GameView view) {
        this.game = game;
        this.view = view;
    }

    public void start() {
        game.setPlayerName(view.askPlayerName());

        boolean playing = true;

        while (playing) {
            view.waitAndClean();
            // view.printSecretWord(game.getWORD());// DEBUG
            view.printPoints(game.getPlayerPoints(), game.getMachinePoints());
            view.printAttempts(game.getMAX_FAILS(), game.getCurrentFails());
            view.printCurrentWord(game.getCurrentWord());
            view.printInsertedLetters(game.getInsertedLetters());
            
            if (!game.isWin()) {
                view.askLetterOrWord();

                switch (view.getTypeGame()) {

                    case 1:// ==== MODO LETRA POR LETRA ====
                        if (!game.isGameOver()) {
                            // view.printCurrentWord(game.getCurrentWord());
                            if (game.isAValidLetter(view.askLetter())) {
                                view.printAccert();
                                view.waitAPoquito();
                                game.incrementPlayerPoints();
                            } else {
                                view.printFail();
                                game.incrementMachinePoints();
                                game.incrementFails();
                            }
                        } else {
                            view.printLose();
                            view.printSecretWord(game.getWORD());
                            if (view.gameContinue()) {
                                this.game = game.resetGame();
                            } else {
                                view.waitAndClean();
                                view.printEnd();
                                playing = false;
                            }
                        }
                        break;

                    case 2:// ==== MODO FULL WORD ====
                        if (game.isAValidWord(view.askFullWord())) {
                            // view.printCurrentWord(game);
                            view.printWin();
                            view.waitAPoquito();
                            game.incrementPlayerPoints();

                            if (view.gameContinue()) {
                                this.game = game.resetGame();
                            } else {
                                view.waitAndClean();
                                view.printEnd();
                                playing = false;
                            }

                        } else {

                            view.printLose();
                            view.printSecretWord(game.getWORD());
                            if (view.gameContinue()) {
                                this.game = game.resetGame();
                            } else {
                                view.waitAndClean();
                                view.printEnd();
                                playing = false;
                            }
                        }
                        break;
                }

            } else {
                view.printWin();

                if (view.gameContinue()) {
                    view.waitAndClean();
                    this.game = game.resetGame();
                } else {
                    view.waitAndClean();
                    view.printEnd();
                    playing = false;
                }
            }

        }
    }
}
