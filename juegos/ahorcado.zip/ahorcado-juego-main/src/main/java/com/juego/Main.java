package com.juego;


public class Main {

    public static void main(String[] args) {
        Game game = new Game();
        GameView view = new GameView();
        Controller controller = new Controller(game, view);

        controller.start();

    }

}
