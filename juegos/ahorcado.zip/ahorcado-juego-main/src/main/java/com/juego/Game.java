//CLASE MODELO,logica interna del juego,reglas,puntuación,etc

package com.juego;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.stream.Collectors;

import lombok.Data;//getters/setters/toString,etc

@Data
public class Game {
    private final List<String> WORDS_COLLECTION;// coleccion de palabras precargadas
    private final char[] WORD;// palabra secreta(random(array))
    private HashSet<Character> insertedLetters;// coleccion que guarda las letras que inserto el jugador

    private String playerName;
    private int playerPoints;// cuenta los puntos del jugador
    private int machinePoints;// cuenta los puntos de la maquina
    private final int MAX_FAILS = 7;// maximo de intentos fallidos
    private int currentFails;// contador de intentos fallidos
    private List<Character> currentWord;// palabra objetivo,solo que se inicializa reemplazando todos los caracteres por
                                        // '-',y se va revelando cada letra segun el jugador vaya acertando

    public Game() {

        this.WORDS_COLLECTION = loadWordCollection();
        this.insertedLetters = new HashSet<Character>();
        this.WORD = setRandomWord();

        this.playerPoints = 0;
        this.machinePoints = 0;
        this.currentFails = 0;
        this.currentWord = new ArrayList<>(Collections.nCopies(WORD.length, '-'));
    }

    // ==== MODIFICADO ====//
    public char[] setRandomWord() {// genera la palabra aleatoria
        int randomIndex = (int) (Math.random() * WORDS_COLLECTION.size());
        String wordTemp = this.WORDS_COLLECTION.get(randomIndex);
        return wordTemp.toCharArray();
    }

    public List<String> loadWordCollection() {// inicializa el diccionario txt
        // *getClass()->retorna la clase real del objeto en tiempo de ejecucion
        // *getClassLoader()->retorna el ClassLoader que uso java para cargar esta
        // clase(el classLoader es un objeto especial que sabe como encontrar clases y
        // recursos,en este caso,un archivo de texto)
        // getResourceAsStream()->retorna el recurso en forma de un stream(flujo de
        // bytes)
        try (InputStream is = getClass().getClassLoader().getResourceAsStream("wordsDictionary.txt");
                BufferedReader br = new BufferedReader(new InputStreamReader(is))) {

            return br.lines().collect(Collectors.toList());

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return List.of("wordsDictionaryNotFound");
        }
    }

    public int getCollectionSize() {// esta claro lo que hace este metodo,creo
        return this.WORDS_COLLECTION.size();
    }

    public boolean isAValidLetter(char userLetter) {// comprueba si la letra es valida
        if (!this.insertedLetters.contains(userLetter)) {// comprueba si la letra ya fue insertada/probada por el
                                                         // usuario
            this.insertedLetters.add(userLetter);// insertar la letra en la coleccion

            int index = 0;
            boolean isValid = false;

            for (char wordLetter : WORD) {

                if (wordLetter == userLetter) {
                    revealWordLetter(userLetter, index);// se revela la letra
                    isValid = true;
                }

                index++;
            }

            index = 0;

            return isValid;

        } else {
            return false;
        }
    }

    public void revealWordLetter(char letter, int index) {
        currentWord.set(index, letter);// reemplaza '-' por el caracter indicado
    }

    public boolean isAValidWord(String fullWord) {
        String wordComplete = new String(WORD);
        if (fullWord.equals(wordComplete)) {
            return true;
        } else {
            return false;
        }
    }

    public void incrementPlayerPoints() {
        this.playerPoints++;
    }

    public void incrementMachinePoints() {
        this.machinePoints++;
    }

    public void incrementFails() {
        if (!isGameOver()) {
            this.currentFails++;
        }
    }

    public boolean isGameOver() {
        if (this.currentFails == MAX_FAILS) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isWin() {

        boolean isWin = false;

        String currentAsString = currentWord.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());

        String wordAsString = new String(WORD);

        return currentAsString.equals(wordAsString);
    }

    public String getWORD() {
        return new String(this.WORD);// parsea el char[] a un String
    }

    public Game resetGame() {
        return new Game();
    }
}
