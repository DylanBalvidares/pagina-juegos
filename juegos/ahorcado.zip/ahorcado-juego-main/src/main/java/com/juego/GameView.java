//CLASE VISTA,muestra estado del modelo en pantalla y se encarga de gestionar entradas de usuario

package com.juego;

import java.text.Normalizer;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.HashSet;
import lombok.Data;

@Data
public class GameView {
    private Scanner sc;// scanner
    private final int maxName = 15;// Cantidad maxima de caracteres
    private boolean next;// Es la condicion del while
    private String letter;// Es la letra
    private int selectedOption;// Decision si se continua el juego
    private int typeGame;// Tipo de juego si palabra completa o letra

    public GameView() {
        this.sc = new Scanner(System.in);
        this.next = false;
        this.letter = null;
        this.selectedOption = 0;
        this.typeGame = 0;
    }

    public int askLetterOrWord() {
        while (true) {
            System.out.println("Elije el modo de juego");
            System.out.println("**1- Adivinar letra por letra**");
            System.out.println("**2- Adivinar Palabra completa**");
            try {
                System.out.print("->");
                typeGame = sc.nextInt();
                sc.nextLine();
                if (typeGame == 1 || typeGame == 2) {
                    return typeGame;
                } else {
                    System.out.println("**Opcion invalida**");
                }
            } catch (InputMismatchException ex) {
                System.out.println("**Opcion invalida**");
                sc.nextLine();
            }
        }
    }

    public String askPlayerName() {// leer nombre del jugador
        String nombre;

        while (true) {
            System.out.println("----------------");
            System.out.print("**Tu nombre:");
            nombre = sc.nextLine();
            System.out.println("----------------");
            if (nombre.length() > maxName) {
                System.out.println("----------------");
                nombre = sc.nextLine();
                System.out.println("----------------");
                System.out.print("**Tu nombre:");
                System.out.println("**Te pasaste de los caracteres permitidos**");
            } else {
                return nombre;
            }
        }
    }

    public char askLetter() {// para leer letras
        while (true) {
            System.out.print("Letra:");
            letter = sc.nextLine();
            letter = letter.toLowerCase();
            letter = removeAccents(letter);
            if (letter.length() == 1) {
                return letter.charAt(0);
            } else {
                System.out.println("*Solo se admite 1 letra*");

            }
        }
    }

    public String askFullWord() {
        System.out.print("Palabra completa:");
        String fullWord = sc.nextLine();
        fullWord = fullWord.toLowerCase();
        fullWord = fullWord.replaceAll("\\p{M}", "");
        return fullWord;
    }

    public boolean gameContinue() {// para leer si el jugador quiere seguir jugando
        System.out.println("----------------------");
        System.out.println("Quieres seguir jugando?");
        System.out.println("----------------------");
        System.out.println("1- Si");
        System.out.println("2- No");

        while (true) {
            try {
                System.out.print("->");
                selectedOption = sc.nextInt();
                sc.nextLine();
                if (selectedOption == 1) {
                    return true;
                } else {
                    return false;
                }

            } catch (InputMismatchException ex) {
                System.out.println("**Opcion invalida**");
                sc.nextLine();
            }

        }
    }

    public void printPoints(int playerPoints, int machinePoints) {
        System.out.println("===========PUNTUACION===========");
        System.out.println("***PLAYER POINTS:" + playerPoints);
        System.out.println("***MACHINE POINTS:" + machinePoints);
        System.out.println("================================");

    }

    public void printAttempts(int attempts, int currentAttemps) {
        System.out.println("================================");
        System.out.println("**MAX ATTEMPTS:" + attempts);
        System.out.println("**CURRENT ATTEMPTS:" + currentAttemps);
        System.out.println("================================");
    }

    public void printCurrentWord(List<Character> currentWord) {
        StringBuilder stringifyWord = new StringBuilder();// esta clase es un String,pero admite metodos como append
        for (char letter : currentWord) {
            stringifyWord.append(letter);
        }

        System.out.println("===============");
        System.out.println("||  " + stringifyWord + "  ||");
        System.out.println("===============");
    }

    public void printSecretWord(String secretWord) {
        System.out.println("**La palabra era->" + secretWord);
    }

    public void printCurrentWord(Game game) {
        System.out.println("=======WORD======");
        System.out.println("||  " + game.getWORD() + "  ||");
        System.out.println("===============");
    }

    public void printInsertedLetters(HashSet<Character> insertedLetters) {
        System.out.println("===============");
        System.out.println("||   LETTERS    ");
        System.out.println("||  " + insertedLetters.toString());
        System.out.println("===============");
    }

    public void printLose() {
        System.out.println("***¡PERDISTE!***");
    }

    public void printFail() {
        System.out.println("***¡NO ACERTASTE!***");
    }

    public void printAccert() {
        System.out.println("***¡ACERTASTE LA LETRA!***");
    }

    public void printWin() {
        System.out.println("***¡ADIVINASTE LA PALABRA!***");
    }

    public void printEnd() {
        System.out.println("***¡ADIOS!***");
    }

    public String removeAccents(String input) {
        if (input == null) {
            return null;
        }
        String normalized = Normalizer.normalize(input, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        return pattern.matcher(normalized).replaceAll("");
    }

    public void clearTerminal() {
        try {
            new ProcessBuilder("clear").inheritIO().start().waitFor();
        } catch (Exception e) {
            System.err.println("CLEAN->" + e);
        }
    }

    public void waitAndClean() {
        try {
            Thread.sleep(450);
            clearTerminal();
        } catch (Exception e) {
            System.err.println("Exception->" + e);
        }
    }

    public void waitAPoquito() {
        try {
            Thread.sleep(450);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
